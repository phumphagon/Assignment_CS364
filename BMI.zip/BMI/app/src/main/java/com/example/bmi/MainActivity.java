package com.example.bmi;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    DecimalFormat formatter = new DecimalFormat("#,###.##");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // --- กำหนดตัวแปร EditText ---
        EditText edit_text2 = findViewById(R.id.editTextText2); // น้ำหนัก
        EditText edit_text3 = findViewById(R.id.editTextText3); // ส่วนสูง
        TextView edit_text4 = findViewById(R.id.editTextText4); // แสดงผล BMI
        TextView edit_text5 = findViewById(R.id.editTextText5); // แสดงผลลัพธ์การตีความ BMI

        // --- กำหนด Filter ---
        edit_text2.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(8, 2)});
        edit_text3.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(8, 2)});

        // --- ปุ่มคำนวณ BMI ---
        Button btnCalculate = findViewById(R.id.button);
        btnCalculate.setOnClickListener(v -> {

            String sWeight = edit_text2.getText().toString();
            String sHeight = edit_text3.getText().toString();

            if (!sWeight.isEmpty() && !sHeight.isEmpty()) {
                try {
                    double weight = Double.parseDouble(sWeight);
                    double heightCm = Double.parseDouble(sHeight);
                    double heightM = heightCm / 100.0;

                    if (heightM > 0) {
                        double bmi = weight / (heightM * heightM);
                        String bmiResult = formatter.format(bmi);
                        edit_text4.setText(bmiResult);

                        // ✅ แปลผล BMI
                        String bmiCategory;
                        int color;
                        if (bmi < 16) {
                            bmiCategory =  getString(R.string.result_1);
                            color = getColor(R.color.red);
                        } else if (bmi < 17) {
                            bmiCategory = getString(R.string.result_2);
                            color = getColor(R.color.light_red);
                        } else if (bmi < 18.5) {
                            bmiCategory = getString(R.string.result_3);
                            color = getColor(R.color.yellow);
                        } else if (bmi < 25) {
                            bmiCategory = getString(R.string.result_4);
                            color = getColor(R.color.green);
                        } else if (bmi < 30) {
                            bmiCategory = getString(R.string.result_5);
                            color = getColor(R.color.yellow);
                        } else if (bmi < 35) {
                            bmiCategory = getString(R.string.result_6);
                            color = getColor(R.color.light_red);
                        } else if (bmi < 40) {
                            bmiCategory = getString(R.string.result_7);
                            color = getColor(R.color.red);
                        } else {
                            bmiCategory = getString(R.string.result_8);
                            color = getColor(R.color.heavy_red);
                        }
                        edit_text5.setTextColor(color);
                        edit_text5.setText(bmiCategory);

                    } else {
                        edit_text4.setText("Invalid height");
                        edit_text5.setText("");
                    }
                } catch (NumberFormatException e) {
                    edit_text4.setText("Invalid input");
                    edit_text5.setText("");
                }
            } else {
                edit_text4.setText("Please enter weight & height");
                edit_text5.setText("");
            }
        });
    }
}

// --- คลาสจำกัดตัวเลข ---
class DecimalDigitsInputFilter implements InputFilter {
    private Pattern mPattern;

    DecimalDigitsInputFilter(int digits, int digitsAfterZero) {
        mPattern = Pattern.compile(
                "[0-9]{0," + (digits - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
    }

    @Override
    public CharSequence filter(CharSequence source, int start, int end,
                               Spanned dest, int dstart, int dend) {
        Matcher matcher = mPattern.matcher(dest);
        if (!matcher.matches()) return "";
        return null;
    }
}
